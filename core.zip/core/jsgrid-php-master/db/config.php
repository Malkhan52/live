<?php

return array(
    "db" => "mysql:host=127.0.0.1;dbname=nu2018",
    "username" => "root",
    "password" => "qwerty"
);

?>
